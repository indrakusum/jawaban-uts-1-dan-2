public class teori {
    Suatu matriks digunakan untuk menyatakan adjacency set setiap verteks dalam baris-barisnya. Nomor baris menyatakan nomor verteks adjacency berasal dan nomor kolom menunjukkan nomor verteks kemana arah adjacency. Elemen matriks [x, y] berharga 1 bila terdapat sisi dari x ke y dan berharga 0 bila tidak ada.
    Harga biner ini memungkinkan penggunaan 1 bit untuk setiap sel matriks. Misalnya pada suatu graph dengan jumlah verteks 48 dapat digunakan 6 byte perbaris (semua 38 baris, jadi diperlukan 48 x 6 byte). Untuk mengetahui harga elemen matrilks maka diperlukan operasi shift-right serts operasi boolean and. Misalnya adjacency dari verteks 15 ke verteks 27 pada contoh 48 verteks di atas maka byte ke ë 27/8û dari baris ke 15 di-shift-right sebanyak (27 mod 8) posisi lalu di-and-kan dengan bilangan 1. Bila hasilnya 1 maka 15 adjacent ke 27, bila 0 maka tidak.


    Rekursivitas dilakukan dalam fungsi Traverse()
    class Graph {
....
        void DFS() {
            for (each vertex v in G)
            v.Status = false;
            for (each vertex v in G)
            if (v.Status == false)
                Traverse(v);
        }
        void Traverse(Vertex v) {
            Vertex w;
            w.Visit();
            v.Status = true;
            for (each adjac. vertex w from v) {
                if (w.Status == false)
                    Traverse(w);
            }
        }
    }
}
    Implementasi algoritma DFS nonrekursif
    Memanfaatkan stack sebagai struktur data pendukung
class Graph {
....
    void DFS() {
        Stack s = new Stack();
        Vertex v, w, t;
        for (each vertex v in G)
        v.Status = false;
        for (each vertex v in G) {
            s.push(v);
            while (s.emptyStack() == false){
                w=s.pop();
                if (v.Status == false) {
                    visit(w);
                    v.Status = true;
                    for (each adjac. vertex t from w)
                    s.push(t);
                }
            }
        }
    }
}


class Graph {
....
    void BFS() {
        Queue q = new Queue();
        Vertex v, w, t;
        for (each vertex v in G)
        v.Status = false;
        for (each vertex v in G) {
            if (v.Status == false) {
                v.Status = true;
                q.add(v);
                while (EmptyQueue(Q) == false){
                    w = q.remove();
                    visit(w);
                    for (each adjac. vertex T from w){
                        if (t.Status == false) {
                            t.Status = true;
                            q.add(t);
                        }
                    }
                }
            }
        }
    }
}
}
