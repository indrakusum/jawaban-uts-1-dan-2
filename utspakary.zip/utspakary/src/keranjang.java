import java.util.Scanner;

public class keranjang {
    public static void main(String[] args) {
String barang [] =new barang[]();
for (int index=0;index<1;index++){
barang = new barang();
    Scanner inputDetail = new Scanner(System.in)
    System.out.println("masukan nama");
    barang.nama= inputDetail.nextLine();

    System.out.println("Masukkan harga :");
    barang.harga = inputDetail.nextLine();

    System.out.println("Masukkan jenis: ");
    barang.jenis = inputDetail.nextLine();


    for(int i=0;i<barang.length();i++){
        String nama= nama.get(i).nama;
        String harga = harga.get(i).harga;
        String jenis= jenis.get(i).jenis;
        System.out.println("jenis " + i+1);
        System.out.println("harga : " + harga);
        System.out.println("Nama  : " + nama);
        System.out.println();


}
    }
}
