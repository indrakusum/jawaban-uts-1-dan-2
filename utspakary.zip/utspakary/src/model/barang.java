package model;

public class barang {
    public String nama;
    public  String harga;
    public  String jenis;
    private int jumlah;

   public barang(){

   }

    public barang(String nama,String harga,String jenis){
        this.nama = nama;
        this.harga =harga;
        this.jenis = jenis;
        this.jumlah = 0;
    }
    public int Deposit(int jumlah){
        jumlah = jumlah + jumlah;
        return jumlah;
    }

    public int Withdraw(int jumlah){
        jumlah = jumlah-jumlah;
        return jumlah;
    }
}
